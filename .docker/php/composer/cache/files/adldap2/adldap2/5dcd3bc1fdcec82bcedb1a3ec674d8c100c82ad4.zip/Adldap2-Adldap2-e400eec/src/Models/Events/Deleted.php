<?php

namespace Adldap\Models\Events;

class Deleted extends Event
{
    //
}
