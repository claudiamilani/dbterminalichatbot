<?php

namespace Adldap\Query\Events;

class Read extends QueryExecuted
{
    //
}
