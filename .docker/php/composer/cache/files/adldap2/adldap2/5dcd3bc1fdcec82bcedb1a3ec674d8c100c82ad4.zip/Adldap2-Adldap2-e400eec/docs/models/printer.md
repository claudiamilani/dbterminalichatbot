# The Printer Model

## Methods

```php
$printer->getPrinterName();

$printer->getPrinterShareName();

$printer->getMemory();

$printer->getUrl();

$printer->getLocation();

$printer->getServerName();

$printer->getColorSupported();

$printer->getDuplexSupported();

$printer->getMediaSupported();

$printer->getStaplingSupported();

$printer->getPrintBinNames();

$printer->getPrintMaxResolution();

$printer->getPrintOrientations();

$printer->getDriverName();

$printer->getDriverVersion();

$printer->getPriority();

$printer->getPrintStartTime();

$printer->getPrintEndTime();

$printer->getPortName();

$printer->getVersionNumber();

$printer->getPrintRate();

$printer->getPrintRateUnit();
```
