<?php

namespace Adldap\Models\Events;

class Updated extends Event
{
    //
}
