<?php

namespace Adldap\Auth;

use Adldap\AdldapException;

class PasswordRequiredException extends AdldapException
{
    //
}
