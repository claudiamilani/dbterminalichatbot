<?php

namespace Adldap\Auth\Events;

class Passed extends Event
{
    //
}
