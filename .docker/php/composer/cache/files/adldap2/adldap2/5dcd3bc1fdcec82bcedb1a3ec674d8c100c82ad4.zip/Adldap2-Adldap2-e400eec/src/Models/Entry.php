<?php

namespace Adldap\Models;

/**
 * Class Entry.
 *
 * Represents an LDAP record that could not be identified as another type of model.
 */
class Entry extends Model
{
    //
}
