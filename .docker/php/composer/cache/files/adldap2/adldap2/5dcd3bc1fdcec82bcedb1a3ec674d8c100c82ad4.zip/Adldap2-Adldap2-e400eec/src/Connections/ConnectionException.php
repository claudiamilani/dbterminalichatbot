<?php

namespace Adldap\Connections;

use Adldap\AdldapException;

class ConnectionException extends AdldapException
{
    //
}
