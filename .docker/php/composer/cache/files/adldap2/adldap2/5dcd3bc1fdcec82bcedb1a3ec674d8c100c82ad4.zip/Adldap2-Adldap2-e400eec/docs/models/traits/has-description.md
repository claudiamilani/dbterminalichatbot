# HasDescription Trait

Models that contain this trait, have the `description` attribute.

There are only two methods that accompany this trait:

```php
$model->getDescription();

$model->setDescription('The models description');
```
