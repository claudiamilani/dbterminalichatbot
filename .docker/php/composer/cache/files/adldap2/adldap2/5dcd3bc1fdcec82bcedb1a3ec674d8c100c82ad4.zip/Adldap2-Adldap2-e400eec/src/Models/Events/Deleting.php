<?php

namespace Adldap\Models\Events;

class Deleting extends Event
{
    //
}
