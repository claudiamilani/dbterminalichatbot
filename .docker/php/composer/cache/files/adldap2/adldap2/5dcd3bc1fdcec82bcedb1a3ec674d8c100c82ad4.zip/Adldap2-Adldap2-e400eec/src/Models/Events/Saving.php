<?php

namespace Adldap\Models\Events;

class Saving extends Event
{
    //
}
