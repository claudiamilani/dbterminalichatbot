- Adldap2 Version: #.#
- LDAP Type: <!-- Active Directory / OpenLDAP / FreeIPA / Sun Directory Server? -->
- PHP Version: #.#

<!-- **ISSUES WITHOUT THE ABOVE INFORMATION WILL BE CLOSED!** -->

### Description:


### Steps To Reproduce:
