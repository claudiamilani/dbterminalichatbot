<?php

namespace Adldap\Auth\Events;

class Binding extends Event
{
    //
}
