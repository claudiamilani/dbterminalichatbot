# HasCriticalSystemObject Trait

Models that contain this trait, have the `isCriticalSystemObject` attribute.

There is only one method that accompanies this trait:

```php
if ($model->isCriticalSystemObject()) {

    //

}
```
