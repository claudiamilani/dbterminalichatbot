<?php

namespace Adldap\Query\Events;

class Listing extends QueryExecuted
{
    //
}
