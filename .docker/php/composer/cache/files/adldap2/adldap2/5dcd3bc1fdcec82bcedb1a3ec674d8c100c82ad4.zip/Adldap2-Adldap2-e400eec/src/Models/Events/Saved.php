<?php

namespace Adldap\Models\Events;

class Saved extends Event
{
    //
}
