<?php

namespace Adldap\Query\Events;

class Paginate extends QueryExecuted
{
    //
}
