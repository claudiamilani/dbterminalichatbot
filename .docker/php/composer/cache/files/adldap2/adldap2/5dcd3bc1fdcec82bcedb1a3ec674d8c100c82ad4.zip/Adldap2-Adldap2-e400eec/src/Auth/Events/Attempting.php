<?php

namespace Adldap\Auth\Events;

class Attempting extends Event
{
    //
}
