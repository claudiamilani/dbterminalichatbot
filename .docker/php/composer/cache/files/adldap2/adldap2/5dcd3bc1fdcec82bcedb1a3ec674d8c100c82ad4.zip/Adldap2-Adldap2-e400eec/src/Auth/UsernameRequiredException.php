<?php

namespace Adldap\Auth;

use Adldap\AdldapException;

class UsernameRequiredException extends AdldapException
{
    //
}
