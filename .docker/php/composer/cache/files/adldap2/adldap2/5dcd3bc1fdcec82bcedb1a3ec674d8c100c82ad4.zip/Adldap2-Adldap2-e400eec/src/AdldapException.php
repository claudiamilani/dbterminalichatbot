<?php

namespace Adldap;

class AdldapException extends \Exception
{
    //
}
