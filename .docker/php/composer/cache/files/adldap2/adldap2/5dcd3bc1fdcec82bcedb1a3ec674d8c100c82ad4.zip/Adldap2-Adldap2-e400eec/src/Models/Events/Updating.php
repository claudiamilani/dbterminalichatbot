<?php

namespace Adldap\Models\Events;

class Updating extends Event
{
    //
}
