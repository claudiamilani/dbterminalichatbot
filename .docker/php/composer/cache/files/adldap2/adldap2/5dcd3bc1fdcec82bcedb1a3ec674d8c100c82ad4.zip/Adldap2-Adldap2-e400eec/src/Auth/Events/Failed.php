<?php

namespace Adldap\Auth\Events;

class Failed extends Event
{
    //
}
