<?php

namespace Adldap\Query\Events;

class Search extends QueryExecuted
{
    //
}
