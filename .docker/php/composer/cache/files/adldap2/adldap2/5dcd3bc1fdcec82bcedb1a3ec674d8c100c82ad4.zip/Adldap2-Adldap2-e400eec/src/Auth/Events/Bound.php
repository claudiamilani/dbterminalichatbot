<?php

namespace Adldap\Auth\Events;

class Bound extends Event
{
    //
}
