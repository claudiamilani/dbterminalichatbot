<?php

namespace Adldap\Models\Events;

class Creating extends Event
{
    //
}
