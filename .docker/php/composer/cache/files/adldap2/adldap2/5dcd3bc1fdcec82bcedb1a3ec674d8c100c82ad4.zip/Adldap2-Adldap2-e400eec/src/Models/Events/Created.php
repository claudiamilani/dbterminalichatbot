<?php

namespace Adldap\Models\Events;

class Created extends Event
{
    //
}
