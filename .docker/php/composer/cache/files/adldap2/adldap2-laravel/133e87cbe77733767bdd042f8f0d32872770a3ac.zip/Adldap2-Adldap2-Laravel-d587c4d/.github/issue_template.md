- Laravel Version: #.#
- Adldap2-Laravel Version: #.#
- PHP Version: #.#
- LDAP Type: <!-- ActiveDirectory / OpenLDAP / FreeIPA? -->

<!-- ISSUES WITHOUT THE ABOVE INFORMATION WILL BE CLOSED! -->

### Description:


<!-- Steps to Reproduce is optional. -->
### Steps To Reproduce:
