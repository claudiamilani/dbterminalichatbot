<?php

namespace Yajra\Pdo\Oci8\Exceptions;

use PDOException;

class Oci8Exception extends PDOException
{
}
